#!/bin/sh

. /opt/ros/humble/setup.sh
. /home/ros2_ws/install/setup.sh
exec "$@"
