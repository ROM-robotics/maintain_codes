:github_url: https://github.com/ros-controls/ros2_control/blob/{REPOS_FILE_BRANCH}/doc/migration.rst

Migration Guides: Galactic to Humble
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
This list summarizes important changes between Galactic (previous) and Humble (current) releases, where changes to user code might be necessary.

.. note::

  This list was created in July 2024, earlier changes are not included.
