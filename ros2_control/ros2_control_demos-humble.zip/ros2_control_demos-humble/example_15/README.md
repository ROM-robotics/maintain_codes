# ros2_control_demo_example_15

   This example shows how to integrate multiple robots under different controller manager instances.

Find the documentation in [doc/userdoc.rst](doc/userdoc.rst) or on [control.ros.org](https://control.ros.org/master/doc/ros2_control_demos/example_15/doc/userdoc.html).
