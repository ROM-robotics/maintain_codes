# ros2_control_demo_example_4

   *RRBot* with an integrated sensor.

Find the documentation in [doc/userdoc.rst](doc/userdoc.rst) or on [control.ros.org](https://control.ros.org/master/doc/ros2_control_demos/example_4/doc/userdoc.html).
