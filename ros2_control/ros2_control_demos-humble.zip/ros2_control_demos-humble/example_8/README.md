# ros2_control_demo_example_8

   *RRBot* with an exposed transmission interface.

Find the documentation in [doc/userdoc.rst](doc/userdoc.rst) or on [control.ros.org](https://control.ros.org/master/doc/ros2_control_demos/example_8/doc/userdoc.html).
