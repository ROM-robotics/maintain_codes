range_sensor_broadcaster
==========================================

Controller to publish readings of Range sensors.

Pluginlib-Library: range_sensor_broadcaster

Plugin: range_sensor_broadcaster/RangeSensorBroadcaster (controller_interface::ControllerInterface)
