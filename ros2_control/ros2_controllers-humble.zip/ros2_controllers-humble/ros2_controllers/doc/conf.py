# Configuration file for the Sphinx documentation builder.
# settings will be overridden by rosdoc2, so we add here only custom settings

copyright = "2024, ros2_control development team"
html_logo = "https://control.ros.org/master/_static/logo_ros-controls.png"
