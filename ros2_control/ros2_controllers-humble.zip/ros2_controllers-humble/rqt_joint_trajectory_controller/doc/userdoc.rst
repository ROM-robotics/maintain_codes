:github_url: https://github.com/ros-controls/ros2_controllers/blob/{REPOS_FILE_BRANCH}/rqt_joint_trajectory_controller/doc/userdoc.rst

.. _rqt_joint_trajectory_controller_userdoc:

rqt_joint_trajectory_controller
===============================

rqt_joint_trajectory_controller is a GUI plugin for rqt that allows to command a joint_trajectory_controller.

.. image:: rqt_joint_trajectory_controller.png
  :width: 400
  :alt: rqt_joint_trajectory_controller
