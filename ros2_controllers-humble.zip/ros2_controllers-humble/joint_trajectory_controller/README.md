# joint_trajectory_controllers package

The package implements controllers to interpolate joint's trajectory.

For detailed documentation check the `docs` folder or [ros2_control documentation](https://control.ros.org/).
